BIRDCOM ANDROID APP PROJECT

This is an Android Studio project for a simple WebView app that opens:
https://remarkable-cobbler-9e4315.netlify.app/

App label: Birdcom
Application ID: com.birdcom.app
Minimum Android version: Android 6.0 (API 23)

BUILD ON A COMPUTER
1. Install Android Studio and its Android SDK.
2. Extract this ZIP.
3. In Android Studio choose Open and select the BirdcomAndroid folder.
4. Allow Gradle sync and install the requested Android SDK platform if prompted.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK will be at app/build/outputs/apk/debug/app-debug.apk.

BUILD IN THE CLOUD (requires a GitHub account and a browser)
The .github/workflows/build-apk.yml workflow is included. Upload this project to a GitHub repository, open the repository's Actions tab, select Build Birdcom APK, and run the workflow. When it finishes, open the run and download the Birdcom-debug-apk artifact. GitHub will require sign-in and repository setup.

NOTES
- This project file is not itself an APK; an Android build environment is required to compile it.
- The app loads your existing live website, so website updates appear in the app without rebuilding.
- Internet access is required.
- WhatsApp links and external links are handed to Android to open the appropriate app/browser.
- This is a debug APK for personal testing, not a signed release for Play Store publication.
